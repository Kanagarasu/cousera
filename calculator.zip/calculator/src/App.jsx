import React, { useState } from "react";
import "./App.css";

function App() {
  const [result, setResult] = useState(0);
  const [input, setInput] = useState("");

  const handleInputChange = (e) => {
    setInput(e.target.value);
  };

  const add = () => setResult(result + Number(input));
  const subtract = () => setResult(result - Number(input));
  const multiply = () => setResult(result * Number(input));
  const divide = () => {
    if (Number(input) !== 0) {
      setResult(result / Number(input));
    } else {
      alert("Cannot divide by zero");
    }
  };

  const resetInput = () => setInput("");
  const resetResult = () => setResult(0);

  return (
    <div className="App" style={{ textAlign: "center", marginTop: "40px" }}>
      <h1>Simplest Working Calculator</h1>
      <h2>{result}</h2>

      <input
        type="number"
        value={input}
        onChange={handleInputChange}
        style={{ padding: "8px", fontSize: "16px", marginBottom: "12px" }}
      />
      <br />

      <div style={{ marginTop: "10px" }}>
        <button className="btn" onClick={add}>add</button>
        <button className="btn" onClick={subtract}>subtract</button>
        <button className="btn" onClick={multiply}>multiply</button>
        <button className="btn" onClick={divide}>divide</button>
        <button className="btn danger" onClick={resetInput}>reset input</button>
        <button className="btn danger" onClick={resetResult}>reset result</button>
      </div>
    </div>
  );
}

export default App;
